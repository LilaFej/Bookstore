package fi.haagahelia.bookstore.repository;

import org.springframework.data.repository.CrudRepository;

import fi.haagahelia.bookstore.model.Book;

public interface BookRepository extends CrudRepository<Book, Long> {

}
